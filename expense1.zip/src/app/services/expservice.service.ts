import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ExpserviceService {
  exps = [];
  constructor() { }

  getExpenses(){
    let exp = JSON.parse(localStorage.getItem('expenses'));
     return exp;
  }
  

  
}
