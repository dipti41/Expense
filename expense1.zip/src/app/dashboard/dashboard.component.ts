import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ExpserviceService } from '../services/expservice.service'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  show_form: boolean;
  expenseForm: FormGroup;
  exps = [];
  index: number = null;


  constructor(private fb: FormBuilder,
    private expservice: ExpserviceService) { }

  ngOnInit() {
    this.show_form = false;
    //this.exps = this.expservice.getExpenses();
    //console.log(localStorage.getItem('expenses'));
  }
  showform(index) {
    this.show_form = true;
    //console.log(index);
    if (index != undefined) {
      //console.log(this.exps[index]);
      this.expenseForm.patchValue({
        record_id: index,
        category: this.exps[index].category,
        item: this.exps[index].item,
        amount: this.exps[index].amount,
        expense_date: this.exps[index].datee
      });
    } else {
      this.expenseForm = this.fb.group({
        record_id: [''],
        category: ['', Validators.required],
        item: ['', Validators.required],
        amount: ['', Validators.required],
        expense_date: ['']
      });
    }
  }
  onSubmit(category?: string, item?: string, amount?: any, date?: string, record_id?: any) {
    console.log(record_id);
    let newData = {
      category: category,
      item: item,
      amount: amount,
      datee: date
    }
    if (record_id != '') {
      //this.expservice.updatedata(record_id,newData);
      let start_index = record_id
      let number_of_elements_to_remove = 4;
      let removed_elements = this.exps.splice(start_index, number_of_elements_to_remove, newData);
    } else {
      this.exps.push(newData);
    }
    this.ngOnInit();
    //console.log(this.exps);    
  }
  deletedata(index) {
    //console.log(index);
    if (confirm('Are you sure want to delete.')) {
    this.exps.splice(index, 1);
    }
    //this.ngOnInit();
  }

}
